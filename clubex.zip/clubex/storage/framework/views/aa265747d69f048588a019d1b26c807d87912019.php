<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Ferramenta de admistração de comissões para associados">
    <meta name="author" content="M2F Soluções">

    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <title>Club-EX</title>

    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css" />
    <script src="<?php echo e(asset('assets/js/modernizr.min.js')); ?>"></script>

   <?php echo $__env->yieldPushContent('header'); ?>


</head>

<body>
    <header id="topnav">
        <div class="topbar-main">
            <div class="container-fluid">

                <!-- Logo container-->
                <div class="logo">
                    <!-- Text Logo -->
                    <!--<a href="index.html" class="logo">-->
                    <!--UBold-->
                    <!--</a>-->
                    <!-- Image Logo -->
                    <a href="#" class="logo">
                        <img src="<?php echo e(asset('assets/images/logo_clubex.png')); ?>" alt="" class="img-logo">
                    </a>

                </div>

                <div class="menu-extras topbar-custom">

                    <ul class="list-inline float-right mb-0">

                        <li class="menu-item list-inline-item">
                            <!-- Mobile menu toggle-->
                            <a class="navbar-toggle nav-link">
                                <div class="lines">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </a>
                            <!-- End mobile menu toggle-->
                        </li>

                        <li class="list-inline-item dropdown notification-list">
                            <a class="nav-link dropdown-toggle waves-effect waves-light nav-user text-white"
                                data-toggle="dropdown" href="#" role="button" aria-haspopup="false"
                                aria-expanded="false">
                                Ola <?php echo e(Auth::user()->name); ?>

                            </a>
                            <div class="dropdown-menu dropdown-menu-right profile-dropdown " aria-labelledby="Preview">
                                <!-- item-->
                                <a href="/associate/edit/<?php echo e(Auth::user()->id); ?>" class="dropdown-item notify-item">
                                    <i class="md md-account-circle"></i> <span>Perfil</span>
                                </a>
                                <a href="/user/editPassword/<?php echo e(Auth::user()->id); ?>" class="dropdown-item notify-item">
                                    <i class="md  md-lock-outline"></i> <span>Alterar Senha</span>
                                </a>

                                <!-- item-->
                                <a href="<?php echo e(route('logout')); ?>" class="dropdown-item notify-item" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <i class="md md-settings-power"></i> <span>Logout</span>
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                    style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>

                    </ul>
                </div>



                <!-- end menu-extras -->

                <div class="clearfix"></div>

            </div> <!-- end container -->
        </div>
        <?php if(Auth::user()->category == 1): ?>
        <div class="navbar-custom">
            <div class="container-fluid">
                <div id="navigation">
                    <!-- Navigation Menu-->
                    <ul class="navigation-menu">
                        <li>
                            <a href="/associates"><i class="md md-account-circle"></i>Associados</a>
                        </li>
                        <li>
                            <a href="/rendimento/form"><i class="fa  fa-line-chart"></i>Manutenção de Taxas</a>
                        </li>


                    </ul>
                    <!-- End navigation menu -->
                </div> <!-- end #navigation -->
            </div> <!-- end container -->
        </div> <!-- end navbar-custom -->
        <?php endif; ?>
    </header>
    <div class="wrapper-dashboard">
        <div class="container-fluid">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    © 2019 - ClubEX <small>Import and Export</small>- M2F Soluções WEB
                </div>
            </div>
        </div>
    </footer>
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script><!-- Popper for Bootstrap -->
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/waves.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.scrollTo.min.js')); ?>"></script>

    <!-- App js -->
    <script src="<?php echo e(asset('assets/js/jquery.core.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.app.js')); ?>"></script>


    <?php echo $__env->yieldPushContent('jsImport'); ?>



    <?php echo $__env->yieldPushContent('jsScripts'); ?>
</body>

</html><?php /**PATH /home/madle519/public_html/clubex/resources/views/layouts/layout.blade.php ENDPATH**/ ?>