<?php $__env->startSection('content'); ?>

<div class="account-pages"></div>
<div class="clearfix"></div>
<div class="wrapper-page">
    <div class="card-box">
        <div class="panel-heading">
            <img class="img-logo" src="<?php echo e(asset('assets/images/logo_clubex.png')); ?>" alt="">

        </div>


        <div class="p-20">
            <form class="form-horizontal m-t-20" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group-custom">
                    <input type="email" id="email" name="email" class="<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                        value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus />
                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    <label class="control-label" for="email">
                        E-Mail
                    </label><i class="bar"></i>

                </div>

                <div class="form-group-custom">
                    <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                        name="password" required autocomplete="current-password">

                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                    <label class="control-label" for="password">Senha</label><i class="bar"></i>
                </div>

                <div class="form-group ">
                    <div class="col-12">
                        <div class="checkbox checkbox-primary">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                <?php echo e(old('remember') ? 'checked' : ''); ?>>

                            <label class="form-check-label" for="remember">
                                <?php echo e(__('Remember Me')); ?>

                            </label>
                        </div>

                    </div>
                </div>

                <div class="form-group text-center m-t-40">
                    <div class="col-12">
                        <button class="btn btn-success btn-block text-uppercase waves-effect waves-light"
                            type="submit">Acessar
                        </button>
                    </div>
                </div>

                <div class="form-group m-t-30 m-b-0">
                    <div class="col-12">
                        <?php if(Route::has('password.request')): ?>

                        <a href="<?php echo e(route('password.request')); ?>" class="text-dark"><i class="fa fa-lock m-r-5"></i>
                            Esqueceu
                            sua
                            senha?</a>
                        <?php endif; ?>


                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
<div class="row">
    <div class="col-sm-12 text-center">
        <p class="text-white">Não tem Acesso? <a href="<?php echo e(route('associate.register')); ?>"
                class="text-white m-l-5"><b>Cadastre-se!</b></a>
        </p>

    </div>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/madle519/public_html/clubex/resources/views/auth/login.blade.php ENDPATH**/ ?>